#!/usr/bin/env ruby
# frozen_string_literal: true

require "English"
class Helper
  attr_reader :license_seats, :unlimited_seats, :total_users, :suspended_users, :active_seats, :enterprise_release, :run_slow, :action_services, :action_databases_prefixes

  def initialize(log_file, options)
    @log_file = log_file
    _, text = run_bash %q( /usr/local/share/enterprise/ghe-license-info | grep -Po '^\"seats\"\h?:\h?\K[\d]+' 2>&1 )
    @license_seats = text.to_i
    _, text = run_bash %q( /usr/local/share/enterprise/ghe-license-info | grep -Po '^\"unlimited_seating\"\h:\h\K.+' 2>&1)
    @unlimited_seats = text
    _, text = run_bash "curl -s 127.0.0.1:1337/api/v3/enterprise/stats/all | jq .users.total_users 2>&1"
    @total_users = text.to_i
    _, text = run_bash "curl -s 127.0.0.1:1337/api/v3/enterprise/stats/all | jq .users.suspended_users 2>&1"
    @suspended_users = text.to_i
    @active_seats = total_users - suspended_users

    @run_slow = options[:run_slow]

    _, enterprise_release_semver = run_bash %q( grep RELEASE_VERSION /etc/github/enterprise-release | grep -Po '\d+\.\d+.\d+' )
    @enterprise_release = Gem::Version.create(enterprise_release_semver)

    unless options[:active_seats].nil?
      log_detail "There are #{@active_seats} active seats, but #{options[:active_seats]} we spefied at the command line, will use that"
      @active_seats = options[:active_seats]
    end

    unless options[:enterprise_release].nil?
      log_detail "Enterprise release is #{@enterprise_release}, but #{options[:enterprise_release]} was specified at the command line so will be used instead"
      @enterprise_release = options[:enterprise_release]
    end

    exit_code, services = run_bash "/bin/bash -c '. /usr/local/share/enterprise/ghe-actions-lib; action-services'"
    raise("Fail to get action services") unless exit_code.zero?

    @action_services = services.split
    exit_code, databases = run_bash "/bin/bash -c '. /usr/local/share/enterprise/ghe-actions-lib; actions-db-prefixes'"
    raise("Fail to get action databases prefixes") unless exit_code.zero?

    @action_databases_prefixes = databases.split
  end

  def log(msg)
    line = "[#{Time.now}] #{msg}"
    @log_file.puts line
    $stdout.puts line
  end

  def log_detail(msg)
    line = "[#{Time.now}] #{msg}"
    @log_file.puts line
  end

  def run_bash(command, options = {})
    log_detail "Running: #{command}#{' (silent)' if options[:silent]}"
    text = `#{command}`
    exit_code = $CHILD_STATUS.exitstatus
    log_detail "Exit Code: #{exit_code}"
    unless options[:silent]
      log_detail "Result from the command:"
      log_detail text
    end
    [exit_code, text]
  end

  def run_bash_silent(command, options = {})
    run_bash command, options.merge(silent: true)
  end

  def log_version
    exit_code, = run_bash "[ -d .git ]"
    if exit_code.zero?
      _, version = run_bash "git rev-parse HEAD"
    elsif File.file? "version"
      file = File.open "version"
      version = file.read
    else
      version = "unknown"
    end
    log "Running version: #{version.strip}"
  end

  def running_as_root?
    _, text = run_bash "whoami"
    "root".eql? text.strip
  end

  # Check whether the current version satisfies the given requirement strings.
  # See https://docs.ruby-lang.org/en/2.6.0/Gem/Requirement.html
  def current_release_is(*requirements)
    requirements.all? { |req| Gem::Requirement.create(req).satisfied_by?(@enterprise_release) }
  end

  # Check if script is being run from replica
  # rubocop:disable Naming/PredicateName
  def is_replica
    return false unless File.exist?("/etc/github/repl-state")

    hostname = File.read("/etc/github/repl-state")
    hostname.strip.eql?("replica")
  end
  # rubocop:enable Naming/PredicateName

  def self.get_min_vcpus(seats)
    return 4 if seats < 10
    return 8 if seats.between?(10, 2999)
    return 12 if seats.between?(3000, 4999)
    return 16 if seats.between?(5000, 7999)

    20
  end

  def self.get_min_memory_gb(seats)
    return 29 if seats < 10
    return 59 if seats.between?(10, 2999)
    return 119 if seats.between?(3000, 4999)
    return 149 if seats.between?(5000, 7999)

    160
  end

  def self.get_min_attached_storage_gb(seats)
    return 150 if seats < 10
    return 300 if seats.between?(10, 2999)
    return 500 if seats.between?(3000, 4999)
    return 750 if seats.between?(5000, 7999)

    1000
  end
end
