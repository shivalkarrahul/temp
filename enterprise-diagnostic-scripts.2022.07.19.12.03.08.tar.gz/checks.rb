#!/usr/bin/env ruby
# frozen_string_literal: true

require "helper"
require "forwardable"
require "pre-checks"

module Checks
  class Base
    extend Forwardable
    attr_accessor :status, :message

    def initialize(helper)
      @helper = helper
    end

    def_delegators :@helper, :log, :log_detail, :run_bash, :run_bash_silent, :running_as_root?, :license_seats, :unlimited_seats, :total_users,
                   :suspended_users, :active_seats, :is_replica, :current_release_is, :action_databases_prefixes, :action_services, :run_slow

    # Setters
    def self.name(name)
      @name = name
    end

    def self.issue_url(issue_url)
      @issue_url = issue_url
    end

    # Getters
    def name
      self.class.instance_variable_get(:@name)
    end

    def issue_url
      self.class.instance_variable_get(:@issue_url)
    end

    # Return the pre_checks associated with this check
    def pre_checks
      self.class.pre_checks.map do |req, options|
        pre_check_from_symbol(req).new(@helper, **options)
      end
    end

    def run!
      # Define in child classes
    end

    # Indicates that the check was successful.
    def pass(msg)
      self.status = "✅"
      self.message = msg
    end

    # Indicates the specific problem the check was looking for was found, and customer should follow the steps in the issue to get unblocked.
    def fail(msg)
      self.status = "❗️"
      self.message = "#{msg} - see #{issue_url}"
    end

    # Indicates that the check could not be run because
    # elevated privileges are needed.
    def needs_root
      self.status = "❓"
      self.message = "Please run the script as root with 'sudo'"
    end

    # Indicactes that the check was not performed because
    # it's not applicable to the current appliance.
    def skipped(msg)
      self.status = "🟡"
      self.message = "skipped: #{msg}"
    end

    # Indicates that the check could not be performed because
    # we ran into unexpected errors.
    def error(msg)
      # NOTE: For now we display this is in a similar way to `skipped`.
      self.status = "🟡"
      self.message = "Couldn't perform check: #{msg}"
    end

    class << self
      # skip_unless macro allowing check writers to specify pre-checks which need to be satisfied before a check.
      # These are provided as symbols or hashes, e.g.
      # skip_unless :actions_enabled
      # skip_unless log_file_present: { path: "/my/log/file" }
      def skip_unless(*args, **kwargs)
        args.map do |arg|
          pre_checks << [arg, {}]
        end

        kwargs.map do |arg, options|
          pre_checks << [arg, { **options }]
        end
      end

      def pre_checks
        @pre_checks ||= []
      end

      # Merge pre-checks into the subclass so they can be inherited
      def inherited(subclass)
        super
        subclass.pre_checks.concat(pre_checks)
      end
    end

    private

    # takes a :some_class(a symbol) and turns it into PreChecks::SomeClass(actual Constant of the class name)
    def pre_check_from_symbol(sym)
      constantize("PreChecks::#{classify(sym.to_s)}")
    end

    # Takes "some_class" and turns it into "SomeClass"
    def classify(str)
      str.split("_").collect(&:capitalize).join
    end

    # Takes "SomeClass"(string) and turns it into SomeClass (actual Constant of the class name)
    def constantize(str)
      Object.const_get(str)
    end
  end
end
