#!/usr/bin/env ruby
# frozen_string_literal: true

require "helper"
require "forwardable"

module PreChecks
  # Represents a condition that must be met for a Check to be executed
  class Base
    extend Forwardable

    def_delegators :@helper, :log, :log_detail, :run_bash, :run_bash_silent, :running_as_root?, :license_seats, :unlimited_seats, :total_users,
                   :suspended_users, :active_seats, :is_replica, :current_release_is, :run_slow

    def initialize(helper, *_args, **_kwargs)
      @helper = helper
    end

    def satisfied?
      raise NotImplementedError
    end

    # The message to be displayed on skip
    def message
      "Check #{name} failed."
    end

    def name
      self.class.name
    end
  end

  class RunningAsRoot < Base
    def message
      "Must be run as root"
    end

    def satisfied?
      running_as_root?
    end
  end

  class ActionsEnabled < Base
    def message
      "Actions is not enabled"
    end

    def satisfied?
      exit_code, = run_bash "ghe-config --true app.actions.enabled 2>&1"
      exit_code.zero?
    end
  end

  class SlowChecksEnabled < Base
    def message
      "Slow Checks are not enabled"
    end

    def satisfied?
      run_slow
    end
  end

  class EnterpriseVersion < Base
    def initialize(helper, requirement:)
      super
      @req = requirement
    end

    def message
      "Invalid Enterprise Version. Requires: (#{@req})"
    end

    def satisfied?
      current_release_is(@req)
    end
  end

  class RunningOnPrimary < Base
    def message
      "Must be running on primary"
    end

    def satisfied?
      !is_replica
    end
  end

  class RunningOnReplica < Base
    def message
      "Must be running on replica"
    end

    def satisfied?
      is_replica
    end
  end

  class LogFilePresent < Base
    def initialize(helper, path:)
      super
      @path = path
    end

    def message
      "Log file #{path} is not present"
    end

    def satisfied?
      File.exist?(@path)
    end
  end

  class MssqlHealthy < Base
    def message
      "MSSQL health check failed"
    end

    def satisfied?
      exit_code, = run_bash %q( ghe-mssql-console -y -q "print CONCAT(@@SERVERNAME, ' is alive')" 2>&1 )
      exit_code.zero?
    end
  end
end
