#!/usr/bin/env ruby
# frozen_string_literal: true

require "optparse"

local_dir = File.expand_path(__dir__)
$LOAD_PATH.unshift(local_dir)

require "pre-checks"

$checks_to_run = []
require "checks/actions"
require "checks/aws"
require "checks/instance"
require "checks/mssql"
require "checks/seats"
require "checks/secrets"
require "checks/system"
require "checks/nomad"

options = {}
options[:run_slow] = true
options[:active_seats] = nil

OptionParser.new do |opts|
  opts.banner = "Usage: ./diagnostic.rb [options]"

  opts.on_tail("-h", "--help", "Prints this help") do
    warn opts
    exit 2
  end

  opts.on("-t", "--test TestClassName", "Run a specific test") do |test_name|
    options[:test_name] = test_name

    begin
      options[:test_class] = Object.const_get(test_name)
    rescue NameError
      warn "#{test_name} does not match an available test"
      exit 2
    end
  end

  opts.on("-s", "--skip-slow", "Skip all tests deemed to be slow") do
    options[:run_slow] = false
  end

  opts.on("-a", "--active-seats n", "Fake the number of active seats to be n") do |seats|
    options[:active_seats] = seats.to_i
  end

  opts.on("-r", "--enterprise-release <semver>", "Fake the release version of GHES to be <semver>") do |version|
    options[:enterprise_release] = Gem::Version.create(version)
  end
end.parse!

$checks_to_run = [options[:test_class]] if options[:test_class]

log_file = File.open("full_details.log", "w")
helper = Helper.new(log_file, options)
helper.log_version
helper.log("If your environment is configured for High Availability, please collect the result from the primary and all replicas.")
helper.log("Please share the following output and the contents of the file named full_details.log with support.")

$checks_to_run.map { |check_class| check_class.new(helper) }.each_with_index do |check, index|
  helper.log_detail "-" * 100
  helper.log_detail "Starting #{check.name} (Class: #{check.class})..."

  failing_pre_checks = check.pre_checks.select do |pre_check|
    !pre_check.satisfied?
  rescue => e # rubocop:disable Style/RescueStandardError
    helper.log_detail e.to_s
    true # errors mean the pre_check failed
  end

  if failing_pre_checks.empty?
    begin
      check.run!
    rescue => e # rubocop:disable Style/RescueStandardError
      helper.log_detail e.to_s
      check.fail e.to_s
    end
  elsif failing_pre_checks.detect { |failed_check| failed_check.is_a? PreChecks::RunningAsRoot }
    check.needs_root
  else
    check.skipped "pre-checks failed: #{failing_pre_checks.map(&:message).join(', ')}"
  end

  helper.log "[#{(index + 1).to_s.rjust(2, '0')}/#{$checks_to_run.length}] #{check.status} #{check.name} - #{check.message}"
  helper.log_detail "Finished #{check.name} (Class: #{check.class})"
end

helper.log "ℹ️  Diagnostic scripts completed successfully"
log_file.close
