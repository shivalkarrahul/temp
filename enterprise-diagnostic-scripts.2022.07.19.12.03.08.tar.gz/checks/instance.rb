#!/usr/bin/env ruby
# frozen_string_literal: true

# checks/instance.rb defines GitHub-specific checks that apply to
# a GitHub Enterprise Server instance. A GHES "instance" includes
# all the nodes present in a GHES HA setup or non-HA Cluster.

require "checks"
require "helper"

class MaintenanceMode < Checks::Base
  name "[System] Maintenance Mode"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/35"

  def run!
    exit_code, = run_bash "ghe-maintenance -q 2>&1"
    if exit_code == 1
      pass "The instance is not in maintenance mode"
    else
      fail "The instance is in maintenance mode"
    end
  end
end

$checks_to_run += [
  MaintenanceMode
]
