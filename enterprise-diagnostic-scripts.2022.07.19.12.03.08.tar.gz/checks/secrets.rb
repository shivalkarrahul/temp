#!/usr/bin/env ruby
# frozen_string_literal: true

require "checks"
require "helper"

class DeployerSecretsCheck < Checks::Base
  name "[Secrets] Deployer Secrets Check"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/31"

  def run!
    _, ghe_config_secret = run_bash_silent " ghe-config secrets.launch.deployer-hmac-secret "
    _, deployer_nomad_job_secret = run_bash_silent %q( cat /etc/nomad-jobs/launch/launch-deployer.hcl | grep -Po 'DEPLOYER_HMAC_SECRET\h*=\h*\"\K[a-f0-9]{64}' )
    _, receiver_nomad_job_secret = run_bash_silent %q( cat /etc/nomad-jobs/launch/launch-receiver.hcl | grep -Po 'DEPLOYER_HMAC_SECRET\h*=\h*\"\K[a-f0-9]{64}' )
    _, github_env_secret = run_bash_silent %q( cat /etc/nomad-jobs/github/00-env.hcl | grep -Po 'ENTERPRISE_LAUNCH_DEPLOYER_HMAC_SECRET\h*=\h*\"\K[a-f0-9]{64}' )

    ghe_config_secret.strip!
    deployer_nomad_job_secret.strip!
    receiver_nomad_job_secret.strip!
    github_env_secret.strip!

    if ghe_config_secret == deployer_nomad_job_secret && ghe_config_secret == receiver_nomad_job_secret && ghe_config_secret == github_env_secret
      pass "All launch secrets match"
    else
      fail "One or more of the Launch secrets is mismatched"
    end
  end
end

class CredzSecretsCheck < Checks::Base
  name "[Secrets] Credz Secrets Check"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/32"

  def run!
    _, ghe_config_secret = run_bash_silent " ghe-config secrets.launch.credz-hmac-secret "
    _, deployer_nomad_job_secret = run_bash_silent %q( cat /etc/nomad-jobs/launch/launch-deployer.hcl | grep -Po 'CREDZ_HMAC_SECRET\h*=\h*\"\K[a-f0-9]{64}' )
    _, receiver_nomad_job_secret = run_bash_silent %q( cat /etc/nomad-jobs/launch/launch-receiver.hcl | grep -Po 'CREDZ_HMAC_SECRET\h*=\h*\"\K[a-f0-9]{64}' )
    _, credz_nomad_job_secret = run_bash_silent %q( cat /etc/nomad-jobs/launch/launch-credz.hcl | grep -Po 'CREDZ_HMAC_SECRET\h*=\h*\"\K[a-f0-9]{64}' )
    _, github_env_secret = run_bash_silent %q( cat /etc/nomad-jobs/github/00-env.hcl | grep -Po 'ENTERPRISE_LAUNCH_CREDZ_HMAC_SECRET\h*=\h*\"\K[a-f0-9]{64}' )

    ghe_config_secret.strip!
    deployer_nomad_job_secret.strip!
    receiver_nomad_job_secret.strip!
    credz_nomad_job_secret.strip!
    github_env_secret.strip!

    if ghe_config_secret == deployer_nomad_job_secret && ghe_config_secret == receiver_nomad_job_secret && ghe_config_secret == credz_nomad_job_secret && ghe_config_secret == github_env_secret
      pass "All credz secrets match"
    else
      fail "One or more of the credz secrets is mismatched"
    end
  end
end

class WebhookSecretsCheck < Checks::Base
  name "[Secrets] Webhook Secrets Check"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/33"

  def run!
    _, ghe_config_secret = run_bash_silent " ghe-config secrets.launch.receiver-webhook-secret "
    _, receiver_nomad_job_secret = run_bash_silent %q( cat /etc/nomad-jobs/launch/launch-receiver.hcl | grep -Po 'WEBHOOK_SECRET\h*=\h*\"\K[a-f0-9]{64}' )
    _, hook_config_attributes_secret = run_bash_silent %q( /usr/local/share/enterprise/github-mysql "SELECT hook_config_attributes.value FROM hook_config_attributes INNER JOIN hooks ON hook_config_attributes.hook_id=hooks.id INNER JOIN integrations ON hooks.installation_target_id=integrations.id AND hooks.installation_target_type='Integration' WHERE integrations.name='GitHub Actions' AND hook_config_attributes.key='secret';" | tail -n1 )

    ghe_config_secret.strip!
    receiver_nomad_job_secret.strip!
    hook_config_attributes_secret.strip!

    if ghe_config_secret == receiver_nomad_job_secret && ghe_config_secret == hook_config_attributes_secret
      pass "All receiver secrets match"
    else
      fail "One or more of the receiver secrets is mismatched"
    end
  end
end

class PrivateKeyCheck < Checks::Base
  name "[Secrets] Private Key Check"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/53"

  def run!
    _, ghe_config_private_key = run_bash_silent " ghe-config 'secrets.launch.app-private-key' "

    # These ones have \n (literal) in the results
    _, deployer_private_key = run_bash_silent %q( cat /etc/nomad-jobs/launch/launch-deployer.hcl | grep -Po 'GITHUB_APP_PRIVATE_KEY\h*=\h*\"\K[^\"]*')
    _, heal_workflows_private_key = run_bash_silent %q( cat /etc/nomad-jobs/launch/launch-heal-workflows.hcl | grep -Po 'GITHUB_APP_PRIVATE_KEY\h*=\h*\"\K[^\"]*' )

    # Strip the \n literal out of the last two and replace with actual newlines
    deployer_private_key.gsub!("\\n", "\n")
    heal_workflows_private_key.gsub!("\\n", "\n")

    ghe_config_private_key.strip!
    deployer_private_key.strip!
    heal_workflows_private_key.strip!

    _, public_key_modulo = run_bash %q( /usr/local/share/enterprise/github-mysql "SELECT integration_keys.public_pem FROM integration_keys INNER JOIN integrations ON integration_keys.integration_id=integrations.id WHERE integrations.name=\"GitHub Actions\" order by integration_keys.id desc limit 1;" | tail -n 1 | perl -pe 's/\\\\n/\\n/g' | openssl rsa -modulus -noout -pubin )
    _, private_key_modulo = run_bash " ghe-config 'secrets.launch.app-private-key' | openssl rsa -modulus -noout "

    if ghe_config_private_key != deployer_private_key || ghe_config_private_key != heal_workflows_private_key
      fail "One or more of the app private keys is mismatched"
    elsif private_key_modulo != public_key_modulo
      fail "The app public/private keys aren't a valid pair"
    else
      pass "All private keys match and pair with the public key"
    end
  end
end

class PublicKeyCheck < Checks::Base
  name "[Secrets] Public Key Check"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/54"

  def run!
    _, ghe_config_public_key = run_bash %q( ghe-config secrets.launch.app-public-key | grep -Pzo 'BEGIN PUBLIC KEY-----\s\K[a-zA-Z\d+\/\s]+' )

    # This one has \n (literal) in the result
    _, integrations_public_key = run_bash %q( /usr/local/share/enterprise/github-mysql "SELECT integration_keys.public_pem FROM integration_keys INNER JOIN integrations ON integration_keys.integration_id=integrations.id WHERE integrations.name=\"GitHub Actions\" order by integration_keys.id desc limit 1;" | grep -Po 'BEGIN PUBLIC KEY-----\\\\n\K[a-zA-Z\d+\/(\\\\n)]+' )

    # Strip the \n literals out of the last one and replace with actual newlines
    integrations_public_key.gsub!("\\n", "\n")

    ghe_config_public_key.strip!
    integrations_public_key.strip!

    if ghe_config_public_key == integrations_public_key
      pass "All public keys match"
    else
      fail "Public keys don't match"
    end
  end
end

class AppIdCheck < Checks::Base
  name "[Secrets] App ID Check"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/55"

  def run!
    _, ghe_config_app_id = run_bash " ghe-config secrets.launch.app-id "
    _, integrations_app_id = run_bash %q( /usr/local/share/enterprise/github-mysql "SELECT integrations.id FROM integrations WHERE integrations.name='GitHub Actions';" | tail -n1 )
    _, deployer_app_id = run_bash %q( cat /etc/nomad-jobs/launch/launch-deployer.hcl | grep -Po 'GITHUB_APP_ID\h*=\h*\"\K[\d]+' )
    _, heal_workflows_app_id = run_bash %q( cat /etc/nomad-jobs/launch/launch-heal-workflows.hcl | grep -Po 'GITHUB_APP_ID\h*=\h*\"\K[\d]+' )
    # This may have to change in the future - currently the key only holds 1 app ID but it could hold more in the future
    _, receiver_app_id = run_bash %q( cat /etc/nomad-jobs/launch/launch-receiver.hcl | grep -Po 'GITHUB_ACTIONS_APP_IDS\h*=\h*\"\K[\d]+' )

    ghe_config_app_id.strip!
    integrations_app_id.strip!
    deployer_app_id.strip!
    heal_workflows_app_id.strip!
    receiver_app_id.strip!

    if ghe_config_app_id == integrations_app_id && ghe_config_app_id == deployer_app_id && ghe_config_app_id == heal_workflows_app_id && ghe_config_app_id == receiver_app_id
      pass "All app IDs match"
    else
      fail "One or more of the app IDs is mismatched"
    end
  end
end

class AppRelayIdCheck < Checks::Base
  name "[Secrets] App Relay ID Check"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/56"

  def run!
    _, ghe_config_app_relay_id = run_bash " ghe-config secrets.launch.app-relay-id | base64 -d "
    _, heal_workflows_app_relay_id = run_bash %q( cat /etc/nomad-jobs/launch/launch-heal-workflows.hcl | grep -Po 'GITHUB_SECRETS_APP_RELAY_ID\h*=\h*\"\K[A-Za-z\d+\/=]+' | base64 -d )
    _, deployer_app_relay_id = run_bash %q( cat /etc/nomad-jobs/launch/launch-deployer.hcl | grep -Po 'GITHUB_SECRETS_APP_RELAY_ID\h*=\h*\"\K[A-Za-z\d+\/=]+' | base64 -d )
    _, receiver_app_relay_id = run_bash %q( cat /etc/nomad-jobs/launch/launch-receiver.hcl | grep -Po 'GITHUB_SECRETS_APP_RELAY_ID\h*=\h*\"\K[A-Za-z\d+\/=]+' | base64 -d )
    _, dotcom_app_relay_id = run_bash %q( github-env eval "echo \"puts GitHub.launch_github_app.global_relay_id\" | bin/safe-ruby -r /github/config/environment | base64 -d" )

    ghe_config_app_relay_id.strip!
    heal_workflows_app_relay_id.strip!
    deployer_app_relay_id.strip!
    receiver_app_relay_id.strip!

    if ghe_config_app_relay_id == heal_workflows_app_relay_id && ghe_config_app_relay_id == deployer_app_relay_id &&
       ghe_config_app_relay_id == receiver_app_relay_id && ghe_config_app_relay_id == dotcom_app_relay_id
      pass "All app relay IDs match"
    else
      fail "One or more of the app relay IDs is mismatched"
    end
  end
end

class BotIdCheck < Checks::Base
  name "[Secrets] Bot ID Check"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/57"

  def run!
    _, ghe_config_bot_relay_id = run_bash " ghe-config secrets.launch.bot-relay-id | base64 -d "
    # This may have to change in the future - currently the key only holds 1 bot ID but it could hold more in the future
    _, receiver_bot_relay_id = run_bash %q( cat /etc/nomad-jobs/launch/launch-receiver.hcl | grep -Po 'GITHUB_ACTIONS_BOT_NODE_IDS\h*=\h*\"\K[A-Za-z\d+\/=]+' | base64 -d )
    _, integrations_bot_relay_id = run_bash %q( /usr/local/share/enterprise/github-mysql "SELECT integrations.bot_id FROM integrations WHERE integrations.name='GitHub Actions';" | tail -n1 )
    integrations_bot_relay_id.strip!
    integrations_bot_relay_id = "03:Bot#{integrations_bot_relay_id}"

    ghe_config_bot_relay_id.strip!
    receiver_bot_relay_id.strip

    if ghe_config_bot_relay_id == receiver_bot_relay_id && ghe_config_bot_relay_id == integrations_bot_relay_id
      pass "All bot relay IDs match"
    else
      fail "One or more of the bot relay IDs is mismatched"
    end
  end
end

class LaunchTokenCommunications < Checks::Base
  name "[Secrets] Launch Token Communications"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/49"

  def run!
    _, token_key = run_bash_silent " ghe-config secrets.launch.token-oauth-key "
    _, oauth_key = run_bash_silent " ghe-config secrets.actions.OAuthS2SSigningKey "
    _, deployer_token_key = run_bash_silent " cat /etc/nomad-jobs/launch/launch-deployer.hcl | grep TOKEN_SERVICE_KEY_PEM "

    token_key.strip!
    oauth_key.strip!

    if (match = /"([\S\s]+)"/.match(deployer_token_key))
      deployer_token_key = match[1].gsub('\\n', "\n").strip
    end

    _, token_cert = run_bash_silent " ghe-config secrets.launch.token-oauth-cert "
    _, oauth_cert = run_bash_silent " ghe-config secrets.actions.OAuthS2SSigningCert "
    _, deployer_token_cert = run_bash_silent " cat /etc/nomad-jobs/launch/launch-deployer.hcl | grep TOKEN_SERVICE_CERT_PEM "

    token_cert.strip!
    oauth_cert.strip!

    if (match = /"([\S\s]+)"/.match(deployer_token_cert))
      deployer_token_cert = match[1].gsub('\\n', "\n").strip
    end

    _, fingerprint = run_bash_silent %q( ghe-config secrets.launch.token-oauth-cert | openssl x509 -fingerprint -noout | cut -d "=" -f 2 | sed 's/://g' )
    pfx_file_exists = File.exist?("/data/user/actions/certificates/#{fingerprint.strip}.pfx")

    if token_key == oauth_key && token_key == deployer_token_key && token_cert == oauth_cert && token_cert == deployer_token_cert && pfx_file_exists
      pass "Launch and token communications secrets match"
    else
      fail "One or more of the launch and token communication secrets do not match"
    end
  end
end

$checks_to_run += [
  DeployerSecretsCheck,
  CredzSecretsCheck,
  WebhookSecretsCheck,
  PrivateKeyCheck,
  PublicKeyCheck,
  AppIdCheck,
  AppRelayIdCheck,
  BotIdCheck,
  LaunchTokenCommunications
]
