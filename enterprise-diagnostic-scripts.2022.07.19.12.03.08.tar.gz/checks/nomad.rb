#!/usr/bin/env ruby
# frozen_string_literal: true

require "checks"

class NomadJobsFailures < Checks::Base
  name "[Nomad] Jobs Failures"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/44"
  skip_unless log_file_present: { path: "/data/user/common/ghe-config.log" }

  def run!
    # Looking for '==> Evaluation "73931e44" finished with status "failed"'
    exit_code, = run_bash %q( grep '==> Evaluation ".*" finished with status "failed"' /data/user/common/ghe-config.log 2>&1 )

    return fail("Found evidence of failed nomad Jobs") if exit_code.zero?

    pass "No evidence of failed Nomad Jobs"
  end
end

$checks_to_run += [
  NomadJobsFailures
]
