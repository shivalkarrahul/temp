#!/usr/bin/env ruby
# frozen_string_literal: true

# checks/system.rb defines application-agnostic checks that apply
# to the Linux virtual machine or cloud instance GitHub Enterprise
# Server runs on.

require "checks"
require "helper"

class TotalMemory < Checks::Base
  name "[System] Total Memory"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/6"

  def run!
    min_memory_gb = Helper.get_min_memory_gb(active_seats)
    _, total_memory_gb = run_bash 'echo "select memory_total/(1024 * 1024 * 1024) from memory_info;" | osqueryi --list --noheader 2>&1'
    total_memory_gb = total_memory_gb.to_i
    if total_memory_gb < min_memory_gb
      fail "Total memory #{total_memory_gb}GB is less than the min #{min_memory_gb}GB"
    else
      pass "Total memory #{total_memory_gb}GB is above the min #{min_memory_gb}GB"
    end
  end
end

class DiskSize < Checks::Base
  name "[System] Disk Size"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/6"

  MIN_ROOT_DISK_SIZE_GB = 200
  MIN_ROOT_PARTITION_SIZE_GB = (MIN_ROOT_DISK_SIZE_GB / 2) - 4

  def run!
    # Check root storage partition size
    root_partition_size_gb = get_storage_size "/"
    return fail "Root Partition #{root_partition_size_gb}GB is less than the min #{MIN_ROOT_PARTITION_SIZE_GB}GB" if root_partition_size_gb < MIN_ROOT_PARTITION_SIZE_GB

    # Check attached storage size
    user_disk_size_gb = get_storage_size "/data/user"
    min_attached_size = Helper.get_min_attached_storage_gb(active_seats)
    return fail "Data Disk #{user_disk_size_gb}GB is less than the min #{min_attached_size}GB" if user_disk_size_gb < min_attached_size

    pass "Root Partition #{root_partition_size_gb}GB is above the min #{MIN_ROOT_PARTITION_SIZE_GB}GB. " \
         "Data Disk #{user_disk_size_gb}GB is above the min #{min_attached_size}GB"
  end

  # Returns the storage size of the given path in GB
  def get_storage_size(node)
    _, partition_size_gb = run_bash %( echo "select blocks*blocks_size/(1024 * 1024 * 1024) from mounts where path = '#{node}';" | osqueryi --list --noheader 2>&1 )
    partition_size_gb.to_i
  end
end

class VCPURequirements < Checks::Base
  name "[System] Virtual CPU requirements"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/6"

  def run!
    _, vcpu_count = run_bash ' echo "select cpu_logical_cores from system_info;" | osqueryi --list --noheader 2>&1 '
    vcpu_count = vcpu_count.to_i

    min_vcpus = Helper.get_min_vcpus(active_seats)
    if vcpu_count < min_vcpus
      fail "The number of vCPUs the instance has (#{vcpu_count}) is less than the requirement (#{min_vcpus}) for the the number of active users."
    else
      pass "The instance has #{vcpu_count} vCPUs meets the required #{min_vcpus} based on the number of active users"
    end
  end
end

$checks_to_run += [
  TotalMemory,
  DiskSize,
  VCPURequirements
]
